import random
from unittest import result

# CONSTANTS
SUM_OP = 1
SUB_OP = 2
MUL_OP = 3
DIV_OP = 4

# python dict with abstraction of java class (a class in python also is unnecessary)
def generate_activity(id: int) -> dict:
    result = {"professor_id" : 1, "id" : id, "title" : f"Atividade número {id}", "subject" : "Matemática", "theme" : "NONE", "statement" : "NONE", "difficulty" : 2.5, "qtt_answers" : 0, "qtt_wrong_answers" : 0, "n1": -1, "n2": -1, "op": -1}
    random.seed()
    op = random.randint(1, 4)
    n1 = random.randint(1, 75)
    n2 = random.randint(1, 50)
    if op == SUM_OP:
        theme = "Soma"
        statement = f"Qual o resultado da soma {n1} + {n2}?"
    elif op == SUB_OP:
        theme = "Subtração"
        statement = f"Qual o resultado da subtração {n1} - {n2}?"
    elif op == MUL_OP:
        theme = "Multiplicação"
        statement = f"Qual o resultado da multiplicação {n1} * {n2}?"
    elif op == DIV_OP:
        theme = "Divisão"
        statement = f"Qual o resultado da divisão {n1} / {n2}?"
    result["theme"] = theme
    result["statement"] = statement
    result["n1"] = n1
    result["n2"] = n2
    result["op"] = op
    return result

def generate_options(activity: dict, id: int) -> list:
    result1 = {"activity_id": activity["id"], "id": id, "text": "NONE", "is_correct": False}
    result2 = {"activity_id": activity["id"], "id": id+1, "text": "NONE", "is_correct": False}
    result3 = {"activity_id": activity["id"], "id": id+2, "text": "NONE", "is_correct": False}
    result4 = {"activity_id": activity["id"], "id": id+3, "text": "NONE", "is_correct": False}
    result = [result1, result2, result3, result4]
    noption = random.randint(1, 4)
    op = random.randint(0, 3)
    if activity["op"] == SUM_OP:
        result[op]["text"] = str(float(activity["n1"] + float(activity["n2"])))
    elif activity["op"] == SUB_OP:
        result[op]["text"] = str(float(activity["n1"] - float(activity["n2"])))
    elif activity["op"] == MUL_OP:
        result[op]["text"] = str(float(activity["n1"] * float(activity["n2"])))
    else:
        result[op]["text"] = str(float(activity["n1"] / float(activity["n2"])))
    result[op]["is_correct"] = True
    for i,x in enumerate(result):
        if i != op:
            x["text"] = str(float(random.randint(1, 1000000) % (int(activity["n1"]) * int(activity["n2"]))))
    return result

def generate_insert_options(activity: dict, id: int) -> str:
    result = ""
    values = generate_options(activity, id)
    for x in values:
        if x["is_correct"] == True:
            result += f"INSERT INTO option VALUES ({x['activity_id']}, {x['id']}, '{x['text']}', TRUE);\n"
        else:
            result += f"INSERT INTO option VALUES ({x['activity_id']}, {x['id']}, '{x['text']}', FALSE);\n"
        pass
    return result

def generate_insert_activity(values: dict) -> str:
    return f"INSERT INTO activity VALUES ({values['professor_id']}, {values['id']}, '{values['title']}', '{values['subject']}', '{values['theme']}', '{values['statement']}', {values['difficulty']}, {values['qtt_answers']}, {values['qtt_wrong_answers']});"


def main() -> None:
    result_activity = []
    activity_id = 100
    options_id = 401
    max = 50
    while activity_id < max + 100:
        result_activity.append(generate_activity(activity_id))
        activity_id += 1
    with open("comandos.sql", "w") as fp:
        for x in result_activity:
            fp.write(generate_insert_activity(x) + "\n")
            fp.write(generate_insert_options(x, options_id))
            options_id += 4

if __name__ == "__main__":
    main()